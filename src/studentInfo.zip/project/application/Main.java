package studentInfo.project.application;

import studentInfo.project.school.Student;
import studentInfo.project.school.Subject;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        //과목 2개 등록
        Subject lang = new Subject("국어", 0);
        Subject math = new Subject("수학", 1);
        ArrayList<Subject> subjectList = new ArrayList<>();
        subjectList.add(lang);
        subjectList.add(math);

        //학생 데이터 5개 등록
        Student lje = new Student(181213,"이지은", lang);
        Student jwy = new Student(181518, "장원영", math);
        Student wb = new Student(171230, "원빈", lang);
        Student hn = new Student(171255, "하니", lang);
        Student jsc = new Student(171590, "정성찬", math);
        //학생 점수 입력
//        Score score = null;
//        lje.addSubjectScore(score = new Score(lje.studentId, lang, 95));
//        lje.addSubjectScore(score = new Score(lje.studentId, math, 56));
//        jwy.addSubjectScore(score = new Score(jwy.studentId, lang, 95));
//        jwy.addSubjectScore(score = new Score(jwy.studentId, math, 98));
//        wb.addSubjectScore(score = new Score(wb.studentId, lang, 100));
//        wb.addSubjectScore(score = new Score(wb.studentId, math, 88));
//        hn.addSubjectScore(score = new Score(hn.studentId, lang, 89));
//        hn.addSubjectScore(score = new Score(hn.studentId, math, 95));
//        jsc.addSubjectScore(score = new Score(jsc.studentId, lang, 83));
//        jsc.addSubjectScore(score = new Score(jsc.studentId, math, 56));


        //과목에 따라 학생의 점수와 점수 보여주기
        for(Subject subject: subjectList) {
            System.out.println("---------------------------------------");
            System.out.println("\t" + subject.getSubjectName() + "수강생 학점");
            System.out.println("이름 | 학번 | 필수과목 | 점수");
            System.out.println("---------------------------------------");
//            System.out.println(subject.studentList.
//            );
        }


    }
}
