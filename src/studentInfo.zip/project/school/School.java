package studentInfo.project.school;

public class School {

}
